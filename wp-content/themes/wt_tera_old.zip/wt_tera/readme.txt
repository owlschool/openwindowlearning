Thank you for purchasing this theme.
====================================

If you have any questions, please visit the support forums:
http://forums.wellthemes.com