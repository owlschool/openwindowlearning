<?php
/**
 * The Header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="main">
 *
 * @package  WellThemes
 * @file     header.php
 * @author   WellThemes Team
 * @link 	 http://wellthemes.com
 */
?>
<!DOCTYPE html>
<!--[if IE 6]>
<html id="ie6" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 7]>
<html id="ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html id="ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 6) | !(IE 7) | !(IE 8)  ]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->

<head>
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<meta name="viewport" content="width=device-width, initial-scale=1">

<title><?php
	/*
	 * Print the <title> tag based on what is being viewed.
	 */
	global $page, $paged;

	wp_title( '|', true, 'right' );

	echo ' - ';

	// Add the blog name.
	bloginfo( 'name' );

	// Add the blog description for the home/front page.
	$site_description = get_bloginfo( 'description', 'display' );
	if ( $site_description && ( is_home() || is_front_page() ) )
		echo " | $site_description";

	// Add a page number if necessary:
	if ( $paged >= 2 || $page >= 2 )
		echo ' | ' . sprintf( __( 'Page %s', 'wellthemes' ), max( $paged, $page ) );

	?>
</title>
<link rel="profile" href="http://gmpg.org/xfn/11" />
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
<!--[if lt IE 9]>
<script src="<?php echo get_template_directory_uri(); ?>/js/html5.js" type="text/javascript"></script>
<![endif]-->

<?php
	/* We add some JavaScript to pages with the comment form
	 * to support sites with threaded comments (when in use).
	 */
	if ( is_singular() && get_option( 'thread_comments' ) )
		wp_enqueue_script( 'comment-reply' );

	/* Always have wp_head() just before the closing </head>
	 * tag of your theme, or you will break many plugins, which
	 * generally use this hook to add elements to <head> such
	 * as styles, scripts, and meta tags.
	 */
	wp_head();
?>
</head>
<body <?php body_class(); ?>>
	
	<div id="container" class="hfeed">
	
	<header id="header">
		<?php if ( wt_get_option( 'wt_show_top_header' ) == 1 ) { ?>
			<div class="top">
				<div class="inner-wrap">
					<div class="top-menu" style="min-height:33px;">
						
<?php if ( $user_ID ) : ?>
    <?php global $user_identity; ?>
    <?php if (pmpro_hasMembershipLevel(4, $user_ID)) { $profile_url = get_option('siteurl') . '/membership-account/'; } else { $profile_url = get_option('siteurl'). '/wp-admin/profile.php'; } ?>
<?php if (ICL_LANGUAGE_CODE == 'es')
{ ?>
						<b>Hola</b>, <a href="<?php echo $profile_url; ?>"><?php echo $user_identity; ?></a>.  [<a href="<?php echo wp_logout_url(); ?>" title="Salir de esta cuenta">Salir</a>]

<?php }
else
{ ?>
						<b>Howdy</b>, <a href="<?php echo $profile_url; ?>"><?php echo $user_identity; ?></a>.  [<a href="<?php echo wp_logout_url(); ?>" title="Log out of this account">Log Out</a>]
<?php } ?>

<?php else : ?>
<?php if (ICL_LANGUAGE_CODE == 'es')
{ ?>

<form name="loginform" id="loginform" action="http://www.gedboard.com/login/" method="post">
<input value="Nombre de Usuario" type="text" size="20" tabindex="10" name="log" id="user_login"  onfocus="if (this.value == 'Nombre de Usuario') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Nombre de Usuario';}" style="color:#999999; font-style:italic; font-family: 'Open Sans', sans-serif, serif;"/><input value="Contraseña" type="password" size="20" tabindex="20" name="pwd" id="user_pass" onfocus="if (this.value == 'Contraseña') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Contraseña';}" style="border: 1px solid #E7E7E7; color:#999999; font-style:italic; font-family: 'Open Sans', sans-serif, serif;"/>
<input name="rememberme" id="rememberme" value="forever" tabindex="90" type="checkbox"> ¿Me Recuerdas?
<input name="wp-submit" id="wp-submit" value="Entrar" tabindex="100" type="submit" class="main-color-bg button" style="padding-top:4px; padding-bottom:4px;">
<a href="http://www.gedboard.com/membership-account/membership-checkout/?level=4" value="Register" >Inscríbeme</a>
</form>
<?php }
else
{ ?>
<form name="loginform" id="loginform" action="http://www.gedboard.com/wp-login.php" method="post">
<input value="Username" type="text" size="20" tabindex="10" name="log" id="user_login"  onfocus="if (this.value == 'Username') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Username';}" style="color:#999999; font-style:italic; font-family: 'Open Sans', sans-serif, serif;"/><input value="Password" type="password" size="20" tabindex="20" name="pwd" id="user_pass" onfocus="if (this.value == 'Password') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Password';}" style="border: 1px solid #E7E7E7; color:#999999; font-style:italic; font-family: 'Open Sans', sans-serif, serif;"/>
<input name="rememberme" id="rememberme" value="forever" tabindex="90" type="checkbox"> Remember Me?
<input name="wp-submit" id="wp-submit" value="Log In" tabindex="100" type="submit" class="main-color-bg button" style="padding-top:4px; padding-bottom:4px;">
<a href="http://www.gedboard.com/membership-account/membership-checkout/?level=4" value="Register" style="background-color:#ed6124; color:white; padding: 4px;">Sign Up For Tutoring</a>
</form>
<?php } ?> 
<?php endif; ?>					</div>
					
					<div class="search">
						<?php get_search_form(); ?>
					</div>
					
					<div class="social">
<div style="display: inline-block; padding-right: 10px;">
<?php do_action('icl_language_selector'); ?>
				</div>		<ul class="list" style="display: inline-block; border: 0; padding-left: 10px;">
						<?php if (wt_get_option( 'wt_twitter_url' )) { ?>
							<li><a class="twitter" href="<?php echo wt_get_option( 'wt_twitter_url' ); ?>"><i class="fa fa-twitter"></i></a></li>
						<?php } ?>
						
						<?php if (wt_get_option( 'wt_fb_url' )) { ?>
							<li><a class="fb" href="<?php echo wt_get_option( 'wt_fb_url' ); ?>"><i class="fa fa-facebook"></i></a></li>
						<?php } ?>
						
						<?php if (wt_get_option( 'wt_gplus_url' )) { ?>
							<li><a class="gplus" href="<?php echo wt_get_option( 'wt_gplus_url' ); ?>"><i class="fa fa-google-plus"></i></a></li>
						<?php } ?>
						
						<?php if (wt_get_option( 'wt_instagram_url' )) { ?>
							<li><a class="instagram" href="<?php echo wt_get_option( 'wt_instagram_url' ); ?>"><i class="fa fa-instagram"></i></a></li>
						<?php } ?>
						
						<?php if (wt_get_option( 'wt_youtube_url' )) { ?>
							<li><a class="youtube" href="<?php echo wt_get_option( 'wt_youtube_url' ); ?>"><i class="fa fa-youtube-play"></i></a></li>
						<?php } ?>
						
						<?php if (wt_get_option( 'wt_rss_url' )) { ?>
							<li><a class="rss" href="<?php echo wt_get_option( 'wt_rss_url' ); ?>"><i class="fa fa-rss"></i></a></li>
						<?php } ?>
						
						</ul>
					</div>
				</div>
			</div>
		<?php } ?>
		
		<div class="logo-wrap clearfix">
			<div class="inner-wrap">
				<div class="logo">			
					<?php if (wt_get_option( 'wt_logo_url' )) { ?>
						<h1>
							<a href="<?php echo home_url(); ?>" title="<?php bloginfo('name'); ?>">
								<img src="<?php echo wt_get_option( 'wt_logo_url' ); ?>" alt="<?php bloginfo( 'name' ); ?>" />
							</a>
						</h1>	
					<?php } else {?>
						<h1 class="site-title">
							<a href="<?php echo home_url(); ?>" title="<?php bloginfo('name'); ?>">
								<?php bloginfo('name'); ?>
							</a>
						</h1>					
					<?php } ?>	
				</div>

				<?php if (wt_get_option( 'wt_header_ad' )) {?>
					<div class="header-ad">	
						<?php echo wt_get_option( 'wt_header_ad' ); ?>	
					</div>
				<?php } ?>
				
			</div>				
		</div>
		
		<div class="menu-section clearfix">
			<nav id="main-menu" class="clearfix">
				<?php wp_nav_menu( array( 'theme_location' => 'primary-menu', 'container' => '0', 'fallback_cb' => 'wellthemes_main_menu_fallback',) ); ?>
			</nav>
		</div>
		
	</header>	
		
	<section id="main">
		<div class="inner-wrap">
		
			<?php
				if ( get_query_var('paged') ) {
					$paged = get_query_var('paged');
				} elseif ( get_query_var('page') ) {
					$paged = get_query_var('page');
				} else {
					$paged = 1;
				}
							
				if (is_page_template('page-featured.php')&& $paged < 2 ){				
					
					$wt_show_slider = get_post_meta($post->ID, 'wt_meta_show_slider', true);
					
					if ( $wt_show_slider == 1 ){
						get_template_part( 'includes/feat-slider' );
					}
					
					$wt_carousel_title = get_post_meta($post->ID, 'wt_meta_carousel_title', true);
					if ( !empty($wt_carousel_title) ){
						get_template_part( 'includes/feat-list' );
					}
				}
			?>