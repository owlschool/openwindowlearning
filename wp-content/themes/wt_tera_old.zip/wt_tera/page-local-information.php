<?php
/**
 * Template Name: Local Information Page
 * Description: A Page Template to display page content without the sidebar.
 *
 * @package  WellThemes
 * @file     page-local-information.php
 * @author   Well Themes Team
 * @link 	 http://wellthemes.com
 */
?>
<?php get_header(); ?>

<div id="content" class="full-content">
    <?php
        $ged = get_post_meta($post->ID, 'wt_meta_available_test_ged', true);
        $hiset = get_post_meta($post->ID, 'wt_meta_available_test_hiset', true);
        $tasc = get_post_meta($post->ID, 'wt_meta_available_test_tasc', true);

        $scholarships = get_post_meta($post->ID, 'wt_meta_financial_aid_scholarships_for_ged', true);
        if (has_post_thumbnail( $post->ID ) ) {
            $image = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'single-post-thumbnail');
        }
     ?>

    <a name="top"></a>
    <?php if (isset($image)) { ?>
        <img class="alignright wp-image-5821 " src="<?php echo $image[0]; ?>" alt="Alabama" width="400" height="470" />
    <?php } ?>
    <h3>Navigation:</h3>
    <ol>
        <?php if ($ged || $hiset || $tasc) { ?> <li><a href="#tests">Available Tests</a></li> <?php } ?>
        <li><a href="#education">Education Programs</a></li>
        <?php if ($scholarships) { ?> <li><a href="#financialaid">Financial Aid</a></li> <?php } ?>
    </ol>
    <p>&nbsp;</p>

    <p>&nbsp;</p>

    <?php if ($ged || $hiset || $tasc) { ?>
        <a name="tests"></a>
        <p><a href="#top">Go to top</a></p>
        <h2>Available Tests</h2>
        <?php if ($ged) {
            $reg_link = get_post_meta($post->ID, 'wt_meta_available_test_ged_reg_link', true);
            $policy_link = get_post_meta($post->ID, 'wt_meta_available_test_ged_state_policy_link', true);
            ?>
            <h3>GED</h3>

            <?php if ($reg_link !== "") { ?>
                <p>Find a test center and register at:<br/>
                <a href="<?php echo $reg_link; ?>" target="_blank"><?php echo $reg_link; ?></a>
                </p>
            <?php } ?>

            <?php if ($policy_link !== "") { ?>
                <p>Find out about state policies regarding GED at:<br/>
                <a href="<?php echo $policy_link; ?>" target="_blank"><?php echo $policy_link; ?></a>
                <p></p>
            <?php } ?>
        <?php } ?>
        <?php if ($hiset) {
            $reg_link = get_post_meta($post->ID, 'wt_meta_available_test_hiset_reg_link', true);
            $policy_link = get_post_meta($post->ID, 'wt_meta_available_test_hiset_state_policy_link', true);
        ?>
            <h3>HiSET</h3>

            <?php if ($reg_link !== "") { ?>
                <p>Find a test center and register at:<br/>
                <a href="<?php echo $reg_link; ?>" target="_blank"><?php echo $reg_link; ?></a>
                </p>
            <?php } ?>

            <?php if ($policy_link !== "") { ?>
                <p>Find out about state policies regarding HiSET at:<br/>
                <a href="<?php echo $policy_link; ?>" target="_blank"><?php echo $policy_link; ?></a>
                </p>
            <?php } ?>
        <?php } ?>
        <?php if ($tasc) {
            $reg_link = get_post_meta($post->ID, 'wt_meta_available_test_tasc_reg_link', true);
            $policy_link = get_post_meta($post->ID, 'wt_meta_available_test_tasc_state_policy_link', true);
        ?>
            <h3>TASC</h3>

            <?php if ($reg_link !== "") { ?>
                <p>Find a test center and register at:<br/>
                <a href="<?php echo $reg_link; ?>" target="_blank"><?php echo $reg_link; ?></a>
                </p>
            <?php } ?>

            <?php if ($policy_link !== "") { ?>
                <p>Find out about state policies regarding TASC at:<br/>
                <a href="<?php echo $policy_link; ?>" target="_blank"><?php echo $policy_link; ?></a>
                </p>
            <?php } ?>
        <?php } ?>
        <?php $policy_link = get_post_meta($post->ID, 'wt_meta_available_test_general_state_link', true);
            if ($policy_link !== "") {
        ?>
            <h3>General Testing Policies For Your State</h3>
            <a href="<?php echo $policy_link; ?>" target="_blank"><?php echo $policy_link; ?></a>
        <?php } ?>
    <?php } ?>
    <p>&nbsp;</p>

    <p>&nbsp;</p>

    <a name="education"></a>
    <p><a href="#top">Go to top</a></p>
    <h2>Education</h2>
    <h3>School Districts</h3>
    <?php $description = get_post_meta($post->ID, 'wt_meta_school_districts_description', true);
    if ($description === "") { $description = "School districts offer various high school completion programs for students up to 21 years old.";}
    echo '<p>' . $description . '</p>';
    ?>
    <p>
    List of Alternative High Schools and Alternative Learning Programs<br/>
    <?php $link = get_post_meta($post->ID, 'wt_meta_alternative_programs_link_1', true);
    if ($link !== "") {
    ?>
        <a href="<?php echo $link; ?>" target="_blank"><?php echo $link; ?></a><br/>
    <?php } ?>
    <?php $link = get_post_meta($post->ID, 'wt_meta_alternative_programs_link_2', true);
    if ($link !== "") {
        ?>
        <a href="<?php echo $link; ?>" target="_blank"><?php echo $link; ?></a>
    <?php } ?>
    </p>
    <p>
    List of School Districts<br/>
    <?php $link = get_post_meta($post->ID, 'wt_meta_school_districts_link_1', true);
    if ($link !== "") {
        ?>
        <a href="<?php echo $link; ?>" target="_blank"><?php echo $link; ?></a><br/>
    <?php } ?>
    <?php $link = get_post_meta($post->ID, 'wt_meta_school_districts_link_2', true);
    if ($link !== "") {
        ?>
        <a href="<?php echo $link; ?>" target="_blank"><?php echo $link; ?></a>
    <?php } ?>
    </p>

    <p>&nbsp;</p>
    <h3>Community Colleges</h3>
    <?php $description = get_post_meta($post->ID, 'wt_meta_community_colleges_description', true);
    if ($description !== "") { echo '<p>' . $description . '</p>'; } else {
    ?>
        <p>Community colleges provide low cost adult education program (such as GED).</p>
    <?php } ?>

    <p>List of Community Colleges<br/>
    <?php $link = get_post_meta($post->ID, 'wt_meta_community_colleges_link_1', true);
    if ($link !== "") {
        ?>
        <a href="<?php echo $link; ?>" target="_blank"><?php echo $link; ?></a><br/>
    <?php } ?>
    <?php $link = get_post_meta($post->ID, 'wt_meta_community_colleges_link_2', true);
    if ($link !== "") {
        ?>
        <a href="<?php echo $link; ?>" target="_blank"><?php echo $link; ?></a>
    <?php } ?>
    </p>

    <p>&nbsp;</p>
    <h3>Unemployment Offices</h3>
    <?php $description = get_post_meta($post->ID, 'wt_meta_unemployment_offices_description', true);
    if ($description !== "") { echo '<p>' . $description . '</p>'; } else {
        ?>
        <p>Local unemployment offices provide various youth programs to low-income youth (age 14-21) who requires additional assistance to complete an educational program, or to secure and hold employment. Youth services include tutoring, alternative school, summer employment, internships, job training, counseling, etc.</p>
    <?php } ?>

    <p>List of Unemployment Offices<br/>
    <?php $link = get_post_meta($post->ID, 'wt_meta_unemployment_offices_link_1', true);
    if ($link !== "") {
        ?>
        <a href="<?php echo $link; ?>" target="_blank"><?php echo $link; ?></a><br/>
    <?php } ?>
    <?php $link = get_post_meta($post->ID, 'wt_meta_unemployment_offices_link_2', true);
    if ($link !== "") {
        ?>
        <a href="<?php echo $link; ?>" target="_blank"><?php echo $link; ?></a>
    <?php } ?>
    </p>
    <p>&nbsp;</p>

    <p>&nbsp;</p>

    <?php if ($scholarships !== "") { ?>
        <a name="financialaid"></a>
        <p><a href="#top">Go to top</a></p>
        <h2>Financial Aid</h2>
        <h3>Scholarships</h3>
        <?php echo '<p>' . $scholarships . '</p>'; ?>
    <?php } ?>

</div><!-- /content -->
	
<?php get_footer(); ?>