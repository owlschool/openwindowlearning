<div>
<div data-role="header" class="topic-header">
    <div class="learndash-video-info">
        <div class="learndash-video-info-inner">
            <div class="learndash-video-title"><a href="<?php echo get_permalink( $course_id );?>"><?php echo get_the_title( $course_id ); ?></a></div>
            <?php if ($has_access && $logged_in) { ?>
                <div class="learndash-video-status"><?php echo learndash_mark_complete($post); ?></div>
            <?php } ?>
            <div class="ssba">
                <a class="ssba_facebook_share" href="http://www.facebook.com/sharer.php?u=http://www.gedboard.com/courses/ged-mathematics/" target="_blank"><img src="http://www.gedboard.com/wp-content/plugins/simple-share-buttons-adder/buttons/simple/facebook.png" title="Facebook" class="ssba" alt="Share on Facebook"></a>
                <a class="ssba_twitter_share" href="http://twitter.com/share?url=http://www.gedboard.com/courses/ged-mathematics/&amp;text=Free+Online+GED+Course" target="_blank"><img src="http://www.gedboard.com/wp-content/plugins/simple-share-buttons-adder/buttons/simple/twitter.png" title="Twitter" class="ssba" alt="Tweet about this on Twitter"></a>
                <a class="ssba_google_share" href="https://plus.google.com/share?url=http://www.gedboard.com/courses/ged-mathematics/" target="_blank"><img src="http://www.gedboard.com/wp-content/plugins/simple-share-buttons-adder/buttons/simple/google.png" title="Google+" class="ssba" alt="Share on Google+"></a>
                <a class="ssba_linkedin_share ssba_share_link" href="http://www.linkedin.com/shareArticle?mini=true&amp;url=http://www.gedboard.com/courses/ged-mathematics/" target="_blank"><img src="http://www.gedboard.com/wp-content/plugins/simple-share-buttons-adder/buttons/simple/linkedin.png" title="Linkedin" class="ssba" alt="Share on LinkedIn"></a>
            </div>
            <div class="learndash-video-current-lesson"><?php echo $lesson_post->post_title; ?></div>
            <div>
                <ul class="learndash-videos-list">
                    <?php
                        foreach ($topics as $key => $topic) {
                            $class_selected = "learndash-topics-unplayed";
                            if ($topic->ID === $post->ID) {
                                $class_selected .= " learndash-topics-selected";
                            }
                            ?>
                            <li class="<?php echo $class_selected; ?>">
                                <a href="<?php echo get_permalink($topic->ID); ?>" title="<?php echo $topic->post_title; ?>">
                                    <span class="progress-title"><?php echo $topic->post_title; ?></span>
                                </a>
                            </li>
                        <?php }
                    ?>
                </ul>
            </div>
            <?php
                $lesson_posts = learndash_get_lesson_list($course_id);
                foreach($lesson_posts as $k => $p) {
                    if($p->ID == $lesson_post->ID) {
                        $found_at = $k;
                        break;
                    }
                }

                $next_link = 'http://www.gedboard.com/courses/ged-mathematics/';
                $next_lesson = '';
                if(isset($found_at) && !empty($lesson_posts[$found_at+1])) {
                    $next_lesson = 'Next Lesson: ' . $lesson_posts[$found_at + 1]->post_title;
                    $next_topics = learndash_topic_dots($lesson_posts[$found_at + 1]->ID, false, 'array');
                    if(!empty($next_topics)) { 
                        foreach ($next_topics as $key => $next_topic) {
                            $next_link = get_permalink($next_topic->ID);
                            break;
                        }
                    } ?>
                    <div class="learndash-video-next-lesson"><a href="<?php echo $next_link; ?>"><?php echo $next_lesson; ?></a></div>
                <?php }
            ?>
            <div class="learndash_signup_form">
                <p>Sign Up To Get Monthly Updates!</p>
                <?php echo do_shortcode("[mc4wp_form]"); ?>
            </div>                    
        </div>
    </div>
</div>
<div class="learndash-video-content">
<div class="learndash-video-content-inner">
<?php
    $video_url = get_post_meta( $post->ID, '_learndash_topic_video_key', true );
    if (isset($video_url) && $video_url != "") {
?>
    <iframe class="sproutvideo-player" src="<?php echo $video_url; ?>?type=hd&amp;hoverColorTop=f5f3f2" width="640" height="360" frameborder="0" allowfullscreen="allowfullscreen"></iframe>
<?php } ?>
<?php $question_available = get_post_meta( $post->ID, '_learndash_topic_question_1_text', true ) ?>
<?php if ($question_available != "") { ?>
    <h3>Questions Covered In This Video</h3>
	<table style="border-collapse: collapse;">
	<?php $curr_index = 1;
	while (true) {
	    $question_text = get_post_meta( $post->ID, '_learndash_topic_question_' . $curr_index . '_text', true );
		$question_image = get_post_meta( $post->ID, '_learndash_topic_question_' . $curr_index . '_image', true );
				
		if (!isset($question_text) || $question_text == "") {
		    break;
		}
				
		echo '<tr style="border: 0px 0px 0px 0px;">';
		if (isset($question_image) && $question_image != "") {
		    echo '<td style="width:70%; border-top: 0px; border-bottom: 0px; padding: 0px 0px 0px 0px;">' . do_shortcode($question_text) . '</td>';
			echo '<td style="width:30%; border-top: 0px; border-bottom: 0px; padding: 0px 0px 0px 0px;">' . $question_image . '</td>';
		} else {
		    echo '<td style="width:100%; border-top: 0px; border-bottom: 0px; padding: 0px 0px 0px 0px;"><ul><li>' . apply_filters('generate_latex_in_page', $question_text) . '</li></ul></td>';
		}
		echo '</tr>';
		$curr_index++;
	} ?>
	</table>
<?php } ?>
				
<?php echo $content; ?>
</div>
</div>
</div>