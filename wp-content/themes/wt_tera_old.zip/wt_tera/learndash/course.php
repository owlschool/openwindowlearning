<div data-role="header" class="main-header">
    <div class="learndash-topic-info">
        <div class="learndash-topic-info-inner">
            <div class="learndash-course-title"><?php echo get_the_title( $course_id ); ?></div>
            <?php if ($has_access && $logged_in) { ?>
                <div class="learndash-course-status">
                    <?php 
                    $course_progress = get_user_meta($user_id, '_sfwd-course_progress', true);
                    $percentage = 0;
                    $completed = 0;
                    $total = 0;
                    if(!empty($course_progress) && !empty($course_progress[$course_id]) && !empty($course_progress[$course_id]['total'])) {
                        $completed = intVal($course_progress[$course_id]['completed']);
                        $total = intVal($course_progress[$course_id]['total']);
                        $percentage = intVal($completed * 100 / $total);
                        $percentage = ($percentage > 100) ? 100 : $percentage;
                    } ?>
                    <div class="learndash-course-progress">
                        <div class="learndash-course-progress-title"><?php echo sprintf(__("%s out of %s steps completed", "learndash"), $completed, $total); ?></div>
                        <div class="learndash-course-progress-bar">
                            <div class="learndash-course-progress-bar-completed" style="width: <?php echo $percentage; ?>%;"></div>
                        </div>
                    </div>
                </div>
                <div class="learndash_course_content"><?php echo $content; ?></div>
            <?php } else { ?>
                <div class="learndash_course_content"><?php echo $content; ?></div>
            <?php } ?>
            <div class="ssba">
                <a class="ssba_facebook_share" href="http://www.facebook.com/sharer.php?u=http://www.gedboard.com/courses/ged-mathematics/" target="_blank"><img src="http://www.gedboard.com/wp-content/plugins/simple-share-buttons-adder/buttons/simple/facebook.png" title="Facebook" class="ssba" alt="Share on Facebook"></a>
                <a class="ssba_twitter_share" href="http://twitter.com/share?url=http://www.gedboard.com/courses/ged-mathematics/&amp;text=Free+Online+GED+Course" target="_blank"><img src="http://www.gedboard.com/wp-content/plugins/simple-share-buttons-adder/buttons/simple/twitter.png" title="Twitter" class="ssba" alt="Tweet about this on Twitter"></a>
                <a class="ssba_google_share" href="https://plus.google.com/share?url=http://www.gedboard.com/courses/ged-mathematics/" target="_blank"><img src="http://www.gedboard.com/wp-content/plugins/simple-share-buttons-adder/buttons/simple/google.png" title="Google+" class="ssba" alt="Share on Google+"></a>
                <a class="ssba_linkedin_share ssba_share_link" href="http://www.linkedin.com/shareArticle?mini=true&amp;url=http://www.gedboard.com/courses/ged-mathematics/" target="_blank"><img src="http://www.gedboard.com/wp-content/plugins/simple-share-buttons-adder/buttons/simple/linkedin.png" title="Linkedin" class="ssba" alt="Share on LinkedIn"></a>
            </div>
            <div class="learndash_signup_form" style="padding-top: 10px; padding-left: 0px;">
                <p>Sign Up To Get Monthly Updates!</p>
                <?php echo do_shortcode("[mc4wp_form]"); ?>
            </div>
        </div>
    </div>
</div>
<div class="videos-list">
    <div class="videos-list-inner">
        <div class="videos-list-inner-inner">
            <?php if (!$has_access) { ?>
                <?php if ($logged_in === false) { ?>
                    <div class="learndash-course-register"><a href="http://www.gedboard.com/wp-login.php">Sign In</a> or <a href="http://www.gedboard.com/wp-login.php?action=register">Register</a> for free to get access to this course</div>
                <?php } else { ?>
                    <div class="learndash-course-register"><?php echo learndash_payment_buttons($post); ?></div>
                <?php } ?>
            <?php } else { ?>
                <div class="tutorial-overview-block">
                    <?php if (!empty($lessons)) { ?>
                        <div>
                            <div class="lessons-list">
                            <?php foreach($lessons as $lesson) { ?>
                                <div class="tutorial-container">
                                    <?php $topics = @$lesson_topics[$lesson["post"]->ID]; $link = 'http://www.gedboard.com';?>
                                    <div class="tutorial-overview">
                                        <?php if(!empty($topics)) { 
                                            foreach ($topics as $key => $topic) {
                                                $link = get_permalink($topic->ID);
                                                break;
                                            }
                                        } ?>
                                        <h3><a class="tutorial-title" href="<?php echo $link; ?>"><?php echo $lesson["post"]->post_title; ?></a></h3>
                                        <div class="tutorial-description"><?php echo $lesson["post"]->post_content; ?></div>  
                                    </div>
                                    <div class="tutorial-contents">
                                        <div class="contents-box">
                                            <?php if (!empty($lesson["lesson_access_from"])) { ?>
                                                <small class='notavailable_message'>
                                                    <?php echo sprintf(__(' Available on: %s ', "learndash") , date("d-M-Y", $lesson["lesson_access_from"])); ?>
                                                </small>
                                                <?php next;
                                            }  
                                            if (!empty($topics)) { ?>
                                                <ul class="learndash-topics-list">
                                                    <?php foreach($topics as $key => $topic) { ?>
                                                        <?php $topic_completed_class = empty($topic->completed)? "learndash-topics-unplayed":"learndash-topics-played"; ?>
                                                        <li class="<?php echo $topic_completed_class; ?>">
                                                            <a href="<?php echo get_permalink($topic->ID); ?>">
                                                                <span class="progress-title"><?php echo $topic->post_title; ?></span>
                                                            </a>
                                                        </li>
                                                   <?php } ?>
                                                </ul>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                            <?php } ?>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            <?php } ?>
        </div>
    </div>
</div>