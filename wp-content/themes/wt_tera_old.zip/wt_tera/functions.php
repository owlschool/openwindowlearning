<?php
require( get_template_directory() . '/framework/functions.php' );

/**
 * Set the format for the more in excerpt, return ... instead of [...]
 */ 
function wellthemes_excerpt_more( $more ) {
	return '...';
}
add_filter('excerpt_more', 'wellthemes_excerpt_more');

// custom excerpt length
function wellthemes_excerpt_length( $length ) {
    return 20;
}
add_filter( 'excerpt_length', 'wellthemes_excerpt_length');

/**
 * Adds a box to the main column on the Post and Page edit screens.
 */
function topic_add_meta_box() {
    add_meta_box('', 'Video and Questions', 'topic_meta_box_callback', 'sfwd-topic');
}
add_action( 'add_meta_boxes', 'topic_add_meta_box' );

/**
 * Prints the box content.
 * 
 * @param WP_Post $post The object for the current post/page.
 */
function topic_meta_box_callback( $post ) {

	// Add an nonce field so we can check for it later.
	wp_nonce_field( 'topic_meta_box', 'topic_meta_box_nonce' );

	/*
	 * Use get_post_meta() to retrieve an existing value
	 * from the database and use the value for the form.
	 */
	$value = get_post_meta( $post->ID, '_learndash_topic_video_key', true );
	$q1_text_value = get_post_meta( $post->ID, '_learndash_topic_question_1_text', true );
	$q1_image_value = get_post_meta( $post->ID, '_learndash_topic_question_1_image', true );
	$q1_time_value = get_post_meta( $post->ID, '_learndash_topic_question_1_starttime', true );
	$q2_text_value = get_post_meta( $post->ID, '_learndash_topic_question_2_text', true );
	$q2_image_value = get_post_meta( $post->ID, '_learndash_topic_question_2_image', true );
	$q2_time_value = get_post_meta( $post->ID, '_learndash_topic_question_2_starttime', true );
	$q3_text_value = get_post_meta( $post->ID, '_learndash_topic_question_3_text', true );
	$q3_image_value = get_post_meta( $post->ID, '_learndash_topic_question_3_image', true );
	$q3_time_value = get_post_meta( $post->ID, '_learndash_topic_question_3_starttime', true );
	$q4_text_value = get_post_meta( $post->ID, '_learndash_topic_question_4_text', true );
	$q4_image_value = get_post_meta( $post->ID, '_learndash_topic_question_4_image', true );
	$q4_time_value = get_post_meta( $post->ID, '_learndash_topic_question_4_starttime', true );


	echo '<label for="learndash_topic_video_url">';
	echo 'Video URL';
	echo '</label> ';
	echo '<input type="text" id="learndash_topic_video_url" name="learndash_topic_video_url" value="' .  $value  . '" size="100" />';
        echo '<br/>';
	echo '<label for="learndash_topic_question_1_text">';
	echo 'Question 1 Text';
	echo '</label> ';
	echo '<input type="text" id="learndash_topic_question_1_text" name="learndash_topic_question_1_text" value="' .  esc_attr($q1_text_value)  . '" size="100" />';
        echo '<br/>';
	echo '<label for="learndash_topic_question_1_image">';
	echo 'Question 1 Image';
	echo '</label> ';
	echo '<input type="text" id="learndash_topic_question_1_image" name="learndash_topic_question_1_image" value="' . esc_attr($q1_image_value)  . '" size="100" />';
        echo '<br/>';
	echo '<label for="learndash_topic_question_1_time">';
	echo 'Question 1 Start Time (Seconds)';
	echo '</label> ';
	echo '<input type="text" id="learndash_topic_question_1_time" name="learndash_topic_question_1_time" value="' . esc_attr( $q1_time_value ) . '" size="5" />';
        echo '<br/>';
	echo '<label for="learndash_topic_question_2_text">';
	echo 'Question 2 Text';
	echo '</label> ';
	echo '<input type="text" id="learndash_topic_question_2_text" name="learndash_topic_question_2_text" value="' .  esc_attr($q2_text_value)  . '" size="100" />';
        echo '<br/>';
	echo '<label for="learndash_topic_question_2_image">';
	echo 'Question 2 Image';
	echo '</label> ';
	echo '<input type="text" id="learndash_topic_question_2_image" name="learndash_topic_question_2_image" value="' .  esc_attr($q2_image_value)  . '" size="100" />';
        echo '<br/>';
	echo '<label for="learndash_topic_question_2_time">';
	echo 'Question 2 Start Time (Seconds)';
	echo '</label> ';
	echo '<input type="text" id="learndash_topic_question_2_time" name="learndash_topic_question_2_time" value="' . esc_attr( $q2_time_value ) . '" size="5" />';
        echo '<br/>';
	echo '<label for="learndash_topic_question_3_text">';
	echo 'Question 3 Text';
	echo '</label> ';
	echo '<input type="text" id="learndash_topic_question_3_text" name="learndash_topic_question_3_text" value="' . esc_attr($q3_text_value)  . '" size="100" />';
        echo '<br/>';
	echo '<label for="learndash_topic_question_3_image">';
	echo 'Question 3 Image';
	echo '</label> ';
	echo '<input type="text" id="learndash_topic_question_3_image" name="learndash_topic_question_3_image" value="' . esc_attr($q3_image_value)  . '" size="100" />';
        echo '<br/>';
	echo '<label for="learndash_topic_question_3_time">';
	echo 'Question 3 Start Time (Seconds)';
	echo '</label> ';
	echo '<input type="text" id="learndash_topic_question_3_time" name="learndash_topic_question_3_time" value="' . esc_attr( $q3_time_value ) . '" size="5" />';
        echo '<br/>';
	echo '<label for="learndash_topic_question_4_text">';
	echo 'Question 4 Text';
	echo '</label> ';
	echo '<input type="text" id="learndash_topic_question_4_text" name="learndash_topic_question_4_text" value="' .  esc_attr($q4_text_value) . '" size="100" />';
        echo '<br/>';
	echo '<label for="learndash_topic_question_4_image">';
	echo 'Question 4 Image';
	echo '</label> ';
	echo '<input type="text" id="learndash_topic_question_4_image" name="learndash_topic_question_4_image" value="' .  esc_attr($q4_image_value) . '" size="100" />';
        echo '<br/>';
	echo '<label for="learndash_topic_question_4_time">';
	echo 'Question 4 Start Time (Seconds)';
	echo '</label> ';
	echo '<input type="text" id="learndash_topic_question_4_time" name="learndash_topic_question_4_time" value="' . esc_attr( $q4_time_value ) . '" size="5" />';


}

/**
 * When the post is saved, saves our custom data.
 *
 * @param int $post_id The ID of the post being saved.
 */
function topic_save_meta_box_data( $post_id ) {

	/*
	 * We need to verify this came from our screen and with proper authorization,
	 * because the save_post action can be triggered at other times.
	 */

	// Check if our nonce is set.
	if ( ! isset( $_POST['topic_meta_box_nonce'] ) ) {
		return;
	}

	// Verify that the nonce is valid.
	if ( ! wp_verify_nonce( $_POST['topic_meta_box_nonce'], 'topic_meta_box' ) ) {
		return;
	}

	// If this is an autosave, our form has not been submitted, so we don't want to do anything.
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}

	// Check the user's permissions.
	if ( isset( $_POST['post_type'] ) && 'sfwd-topic' == $_POST['post_type'] ) {

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
	} else { return; }

	/* OK, it's safe for us to save the data now. */
	
	// Make sure that it is set.
	if ( isset( $_POST['learndash_topic_video_url'] ) ) {
		// Sanitize user input.
		$my_data = $_POST['learndash_topic_video_url'];

		// Update the meta field in the database.
		update_post_meta( $post_id, '_learndash_topic_video_key', $my_data );
       }

	// Make sure that it is set.
	if ( isset( $_POST['learndash_topic_question_1_text'] ) ) {
		// Sanitize user input.
		$my_data = $_POST['learndash_topic_question_1_text'] ;

		// Update the meta field in the database.
		update_post_meta( $post_id, '_learndash_topic_question_1_text', $my_data );
       }

	if ( isset( $_POST['learndash_topic_question_1_image'] ) ) {
		// Sanitize user input.
		$my_data =  $_POST['learndash_topic_question_1_image'] ;

		// Update the meta field in the database.
		update_post_meta( $post_id, '_learndash_topic_question_1_image', $my_data );
       }

	if ( isset( $_POST['learndash_topic_question_1_time'] ) ) {
		// Sanitize user input.
		$my_data = $_POST['learndash_topic_question_1_time'] ;

		// Update the meta field in the database.
		update_post_meta( $post_id, '_learndash_topic_question_1_starttime', $my_data );
       }

	if ( isset( $_POST['learndash_topic_question_2_text'] ) ) {
		// Sanitize user input.
		$my_data =  $_POST['learndash_topic_question_2_text'] ;

		// Update the meta field in the database.
		update_post_meta( $post_id, '_learndash_topic_question_2_text', $my_data );
       }

	if ( isset( $_POST['learndash_topic_question_2_image'] ) ) {
		// Sanitize user input.
		$my_data =  $_POST['learndash_topic_question_2_image'] ;

		// Update the meta field in the database.
		update_post_meta( $post_id, '_learndash_topic_question_2_image', $my_data );
       }

	if ( isset( $_POST['learndash_topic_question_2_time'] ) ) {
		// Sanitize user input.
		$my_data =  $_POST['learndash_topic_question_2_time'] ;

		// Update the meta field in the database.
		update_post_meta( $post_id, '_learndash_topic_question_2_starttime', $my_data );
       }

	if ( isset( $_POST['learndash_topic_question_3_text'] ) ) {
		// Sanitize user input.
		$my_data = $_POST['learndash_topic_question_3_text'] ;

		// Update the meta field in the database.
		update_post_meta( $post_id, '_learndash_topic_question_3_text', $my_data );
       }

	if ( isset( $_POST['learndash_topic_question_3_image'] ) ) {
		// Sanitize user input.
		$my_data =  $_POST['learndash_topic_question_3_image'];

		// Update the meta field in the database.
		update_post_meta( $post_id, '_learndash_topic_question_3_image', $my_data );
       }

	if ( isset( $_POST['learndash_topic_question_3_time'] ) ) {
		// Sanitize user input.
		$my_data =  $_POST['learndash_topic_question_3_time'] ;

		// Update the meta field in the database.
		update_post_meta( $post_id, '_learndash_topic_question_3_starttime', $my_data );
       }

	if ( isset( $_POST['learndash_topic_question_4_text'] ) ) {
		// Sanitize user input.
		$my_data =  $_POST['learndash_topic_question_4_text'] ;

		// Update the meta field in the database.
		update_post_meta( $post_id, '_learndash_topic_question_4_text', $my_data );
       }

	if ( isset( $_POST['learndash_topic_question_4_image'] ) ) {
		// Sanitize user input.
		$my_data =  $_POST['learndash_topic_question_4_image'] ;

		// Update the meta field in the database.
		update_post_meta( $post_id, '_learndash_topic_question_4_image', $my_data );
       }

	if ( isset( $_POST['learndash_topic_question_4_time'] ) ) {
		// Sanitize user input.
		$my_data =  $_POST['learndash_topic_question_4_time'] ;

		// Update the meta field in the database.
		update_post_meta( $post_id, '_learndash_topic_question_4_starttime', $my_data );
       }
}
//add_action( 'save_post', 'topic_save_meta_box_data' );

function get_inner_html( $node ) {
    $innerHTML= '';
    $children = $node->childNodes;
    foreach ($children as $child) {
        $innerHTML .= $child->ownerDocument->saveXML( $child );
    }

    return $innerHTML;
} 
function topic_save_meta_box_data_temp( $post_id ) {

	/*
	 * We need to verify this came from our screen and with proper authorization,
	 * because the save_post action can be triggered at other times.
	 */

	// Check if our nonce is set.
	if ( ! isset( $_POST['topic_meta_box_nonce'] ) ) {
		return;
	}

	// Verify that the nonce is valid.
	if ( ! wp_verify_nonce( $_POST['topic_meta_box_nonce'], 'topic_meta_box' ) ) {
		return;
	}

	// If this is an autosave, our form has not been submitted, so we don't want to do anything.
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}

	// Check the user's permissions.
	if ( isset( $_POST['post_type'] ) && 'sfwd-topic' == $_POST['post_type'] ) {

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
	} else { return; }

        $dom = new DOMDocument();
        $content_post = get_post($post_id);
        $content = $content_post->post_content;
        $dom->loadHTML($content);
        $xpath = new DOMXPath($dom);
        $iframes = $xpath->query('//iframe');

        foreach($iframes as $iframe)
        {
            $vid_src = $iframe->getAttribute('src');
            $vid_src = substr($vid_src, 0, strpos($vid_src, '?'));
            break;
        }

	/* OK, it's safe for us to save the data now. */
	
	// Make sure that it is set.
	if ( isset( $vid_src ) ) {
		// Update the meta field in the database.
		update_post_meta( $post_id, '_learndash_topic_video_key', $vid_src );
       }
       $questions = $xpath->query('//h3[contains(.,"Questions Covered In This Video")]/following-sibling::*[1][self::ul]/li');
           $curr_question = 1;
           foreach ($questions as $question) {
               $q_text = get_inner_html($question);
               if (isset($q_text)) {
                   update_post_meta($post_id, '_learndash_topic_question_' . $curr_question . '_text', $q_text);
               }
               $curr_question++;
           }

       if ($curr_question > 1) {
           return;
       }

       $questions = $xpath->query('//h3[contains(.,"Questions Covered In This Video")]/following-sibling::*[1][self::table]/tbody/tr');
           $curr_question = 1;
           foreach ($questions as $question) {
               $child = $question->firstChild;
               if ($child !== NULL) {
                   $q_text = get_inner_html($child);
                   if (isset($q_text)) {
                       update_post_meta($post_id, '_learndash_topic_question_' . $curr_question . '_text', $q_text);
                   }

                   $image_node = $child->nextSibling;
                   if ($image_node !== NULL) {
                       $image_text = get_inner_html($image_node);
                       if (isset($image_text)) {
                           update_post_meta($post_id, '_learndash_topic_question_' . $curr_question . '_image', $image_text);
                       }
                   }
               }
               $curr_question++;
           }

}
add_action( 'save_post', 'topic_save_meta_box_data_temp' );

function pmpro_non_member_text_filter_override($existing_page)
{
    $this_postid = url_to_postid( 'http://www.gedboard.com/tutoring-no-access/' );
    $content_post = get_post($this_postid);
    $content = $content_post->post_content;
    //$content = apply_filters('the_content', $content);
    return $content;
}

add_filter('pmpro_non_member_text_filter', 'pmpro_non_member_text_filter_override', 7, 1);
add_filter('pmpro_not_logged_in_text_filter', 'pmpro_non_member_text_filter_override', 7, 1);


/*
  Change cancellation to set expiration date for next payment instead of cancelling immediately.
	
	Assumes orders are generated for each payment (i.e. your webhooks/etc are setup correctly).
*/
//give users their level back with an expiration
function my_pmpro_after_change_membership_level($level_id, $user_id)
{
	//are we on the cancel page?
	global $pmpro_pages, $wpdb;
	if(is_page($pmpro_pages['cancel']))
	{
		/*
			okay, let's give the user his old level back with an expiration based on his subscription date
		*/
		//get last order
		$order = new MemberOrder();
		$order->getLastMemberOrder($user_id, "cancelled");
		
		//get the last level they had		
		$level = $wpdb->get_row("SELECT * FROM $wpdb->pmpro_memberships_users WHERE membership_id = '" . $order->membership_id . "' AND user_id = '" . $user_id . "' ORDER BY id DESC LIMIT 1");

		//can't do this if the level isn't recurring
		if(empty($level->cycle_number))
			return false;
				
		//can't do this unless we find an order and level
		if(empty($order->id) || empty($level))
			return false;
			
		//last payment date
		$lastdate = date("Y-m-d", $order->timestamp);
				
		//next payment date
		$nextdate = $wpdb->get_var("SELECT UNIX_TIMESTAMP('" . $lastdate . "' + INTERVAL " . $level->cycle_number . " " . $level->cycle_period . ")");		
				
		//if the date in the future?
		if($nextdate - time() > 0)
		{						
			//give them their level back with the expiration date set
			$old_level = $wpdb->get_row("SELECT * FROM $wpdb->pmpro_memberships_users WHERE membership_id = '" . $order->membership_id . "' AND user_id = '" . $user_id . "' ORDER BY id DESC LIMIT 1", ARRAY_A);
			$old_level['enddate'] = date("Y-m-d H:i:s", $nextdate);
						
			//disable this hook so we don't loop
			remove_action("pmpro_after_change_membership_level", "my_pmpro_after_change_membership_level", 10, 2);
			
			//change level
			pmpro_changeMembershipLevel($old_level, $user_id);
			
			//add the action back just in case
			add_action("pmpro_after_change_membership_level", "my_pmpro_after_change_membership_level", 10, 2);
			
			//change message shown on cancel page
			add_filter("gettext", "my_gettext_cancel_text", 10, 3);
		}
	}
}
add_action("pmpro_after_change_membership_level", "my_pmpro_after_change_membership_level", 10, 2);
 
//this replaces the cancellation text so people know they'll still have access for a certain amount of time
function  my_gettext_cancel_text($translated_text, $text, $domain)
{
	if($domain == "pmpro" && $text == "Your membership has been cancelled.")
	{
		global $current_user;
		$translated_text = "Your recurring subscription has been cancelled. Your active membership will expire on " . date(get_option("date_format"), pmpro_next_payment($current_user->ID, "cancelled")) . ".";
	}
	
	return $translated_text;
}
 
//want to update the cancellation email as well
function my_pmpro_email_body($body, $email)
{
	if($email->template == "cancel")
	{
		global $wpdb;
		$user_id = $wpdb->get_var("SELECT ID FROM $wpdb->users WHERE user_email = '" . esc_sql($email->email) . "' LIMIT 1");
		if(!empty($user_id))
		{
			$expiration_date = pmpro_next_payment($user_id);
			
			//if the date in the future?
			if($expiration_date - time() > 0)
			{						
				$body .= "<p>Your access will expire on " . date(get_option("date_format"), $expiration_date) . ".</p>";
			}
		}
	}
	
	return $body;
}
add_filter("pmpro_email_body", "my_pmpro_email_body", 10, 2);

 
?>